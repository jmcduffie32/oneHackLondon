import json
import boto3
import os
import requests


def handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    global userTable
    userTable = dynamodb.Table(os.environ['message_table'])
    if event['httpMethod'] == 'POST':
        if event['body']:
            print(event['body'])
            body = json.loads(event['body'])

            if body.get('message_uuid'):
                print('Received an outbound message event!')

            if body.get('msisdn'):
                print('Received an inbound text message!')
                item = findUser(str(body['msisdn']))
                item['message'] = body['text']
                print(f"New item: {item}")
                userTable.put_item(
                    Item=item
                )

            if body.get('sendMessage'):
                user = body['sendMessage']
                message = body['message']
                response = userTable.get_item(
                    Key={
                        'user': user
                    }
                )
                userNumber = response['Item'].get('number')
                print(f"Sending a message to: {body['sendMessage']}")
                payload = {
    "template":"failover",
    "workflow": [
      {
        "from": { "type": "messenger", "id": "213214" },
        "to": { "type": "messenger", "id": "124421" },
        "message": {
          "content": {
            "type": "text",
            "text": "This is a Facebook Messenger Message sent via the Dispatch API"
          }
        },
        "failover":{
          "expiry_time": 15,
          "condition_status": "read"
        }
      },
      {
        "from": {"type": "sms", "number": "447418342701"},
        "to": { "type": "sms", "number": f"{userNumber}"},
        "message": {
          "content": {
            "type": "text",
            "text": f"{message}"
          }
        }
      }
    ]
  }
                headers = {'Authorization:' f"Bearer {os.environ['JWT']}",
                           'Content-Type: application/json', 'Accept: application/json'}
                requests.post('https://api.nexmo.com/v0.1/dispatch',
                              json=payload, headers=headers)

            if body.get('getUsers'):
                print(f"Getting all users in the table")
                response = userTable.scan()
                return {
                    'statusCode': 200,
                    'body': json.dumps({'users': response['Items']})
                }

            if body.get('pollUser'):
                print(f"Getting the message for: {body['pollUser']}")
                response = userTable.get_item(
                    Key={
                        'user': body['pollUser']
                    }
                )
                print(response)
                message = response['Item'].get('message')
                if message:
                    del response['Item']['message']
                    item = response['Item']
                    userTable.put_item(
                        Item=item
                    )
                    return {
                        'statusCode': 200,
                        'body': json.dumps({'message': message})
                    }

                if not message:
                    return {
                        'statusCode': 200,
                        'body': json.dumps({'message': False})
                    }
            return {
                'statusCode': 200
            }

    elif event['httpMethod'] == 'GET':
        return {
            'statusCode': 200
        }


def findUser(number=None):
    response = userTable.scan()
    print(response['Items'])
    for item in response['Items']:
        if item.get('number') == number:
            return item
